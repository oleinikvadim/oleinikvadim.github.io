(function ($) {
  $(document).ready(function () {
    togglerCollapse();
    rectDown();
    myMap();
    blogSlider();
    aos();
    waypointOppotunites ();
    progressAnimate ();
    headerUP ();
    headerBg();
    navMenu();
    scrollSmooth();
  }); 


  function togglerCollapse() {
    $(".JS-hamburger").click(function () {
      $(this).toggleClass("is-active");
      $(".JS-header").addClass("scrolled");
    });
  }
  
  function rectDown() {
    $(".JS-rect-down").on("click", function () {
      // TO DO scroll to the next section
      $("html, body").animate(
        {
          scrollTop: $(".section-features").offset().top,
        },
        1000,
        null,
        function () {
          console.log(11);
        }
      );
    });
  }

  function myMap() {
    var map = new google.maps.Map(document.getElementById("JS-map"),
    { 
      center:new google.maps.LatLng(49.989598, 36.230662),
      zoom:15,
      styles: [
        {
            "featureType": "all",
            "elementType": "geometry",
            "stylers": [
                {
                    "color": "#202c3e"
                }
            ]
        },
        {
            "featureType": "all",
            "elementType": "labels.text.fill",
            "stylers": [
                {
                    "gamma": 0.01
                },
                {
                    "lightness": 20
                },
                {
                    "weight": "1.39"
                },
                {
                    "color": "#ffffff"
                }
            ]
        },
        {
            "featureType": "all",
            "elementType": "labels.text.stroke",
            "stylers": [
                {
                    "weight": "0.96"
                },
                {
                    "saturation": "9"
                },
                {
                    "visibility": "on"
                },
                {
                    "color": "#000000"
                }
            ]
        },
        {
            "featureType": "all",
            "elementType": "labels.icon",
            "stylers": [
                {
                    "visibility": "off"
                }
            ]
        },
        {
            "featureType": "landscape",
            "elementType": "geometry",
            "stylers": [
                {
                    "lightness": 30
                },
                {
                    "saturation": "9"
                },
                {
                    "color": "#29446b"
                }
            ]
        },
        {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [
                {
                    "saturation": 20
                }
            ]
        },
        {
            "featureType": "poi.park",
            "elementType": "geometry",
            "stylers": [
                {
                    "lightness": 20
                },
                {
                    "saturation": -20
                }
            ]
        },
        {
            "featureType": "road",
            "elementType": "geometry",
            "stylers": [
                {
                    "lightness": 10
                },
                {
                    "saturation": -30
                }
            ]
        },
        {
            "featureType": "road",
            "elementType": "geometry.fill",
            "stylers": [
                {
                    "color": "#193a55"
                }
            ]
        },
        {
            "featureType": "road",
            "elementType": "geometry.stroke",
            "stylers": [
                {
                    "saturation": 25
                },
                {
                    "lightness": 25
                },
                {
                    "weight": "0.01"
                }
            ]
        },
        {
            "featureType": "water",
            "elementType": "all",
            "stylers": [
                {
                    "lightness": -20
                }
            ]
        }
    ]
    });
  }
  
  function aos() {
    AOS.init({
      once: true,
      delay : 300,
    });
  }

  function progressAnimate() {
  //  $(".progress-bar").animate({
  //   width: "100%"
  // }, 2500); 
  } 
  
  function blogSlider(){
    $('.JS-blog-slider').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            slidesToShow: 2,
            dots: true,
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1,
            dots: true,
          }
        }
      ]
    });
  }
 
  function waypointOppotunites () {
    var waypoint = new Waypoint({
      element: document.getElementById('opportunetes'),
      handler: function progressAnimate() {
        $(".progress-bar").animate({
          width: "100%"
        }, 2500);
      },
    })
  }

  function headerUP() {
    var prevScrollpos = window.pageYOffset;
    window.onscroll = function() {
      var currentScrollPos = window.pageYOffset;
        if (prevScrollpos > currentScrollPos) {
          document.getElementById("header").style.top = "0";
        } else {
            document.getElementById("header").style.top = "-152px";
          }
          prevScrollpos = currentScrollPos;
      }
   }

  function headerBg() {
    $(document).scroll(function () {
      var $header = $(".JS-header");
    $header.toggleClass('scrolled', $(this).scrollTop() > $header.height());
  });
  }
  function navMenu(){
    $(".nav-link").click(function() {
      $(".navbar-collapse").toggleClass("show");
      $(".JS-hamburger").removeClass("is-active");

    })
  }
 
  function scrollSmooth() {
    $(document).ready(function(){
      // Add smooth scrolling to all links
      $(".nav-link").on('click', function(event) {
    
        // Make sure this.hash has a value before overriding default behavior
        if (this.hash !== "") {
          // Prevent default anchor click behavior
          event.preventDefault();
    
          // Store hash
          var hash = this.hash;
    
          // Using jQuery's animate() method to add smooth page scroll
          // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
          $('html, body').animate({
            scrollTop: $(hash).offset().top
          }, 800, function(){
    
            // Add hash (#) to URL when done scrolling (default click behavior)
            window.location.hash = hash;
          });
        } // End if
      });
    });
  }
})(jQuery);
